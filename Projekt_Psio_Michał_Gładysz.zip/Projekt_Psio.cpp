﻿#include <SFML/Graphics.hpp>
#include <time.h>
#include <vector>
#include <iostream>
#include <Windows.h>

int los()
{
    int a = rand() % 3 + 1;
    return a;
}


int main()
{
    srand(time(0));

    sf::RenderWindow app(sf::VideoMode(520, 450), "Gra_Psio");
    app.setFramerateLimit(60);

    sf::Texture t1, t2, t3, t4, t5, t6, t7, t8, t9;
    t1.loadFromFile("images/block01.png");
    t2.loadFromFile("images/background1.jpg");
    t3.loadFromFile("images/ball.png");
    t4.loadFromFile("images/paddle.png");
    t5.loadFromFile("images/heart.png");
    t6.loadFromFile("images/heart2.png");
    t7.loadFromFile("images/gameover.jpg");
    t8.loadFromFile("images/win.png");
    t9.loadFromFile("images/block02.png");

    sf::Sprite sBackground(t2), sBall(t3), sPaddle(t4);
    sPaddle.setPosition(300, 440);
    sBackground.setScale(0.3, 0.3);
    sBackground.setPosition(-30, -115);
    sf::Sprite Gameover(t7);
    sf::Sprite Win(t8);

    std::vector<sf::Sprite> hearts;
    std::vector<sf::Sprite> blocks;
    std::vector<sf::Sprite> hearts2;
    std::vector<sf::Sprite> blocks2;

    

    for (int i = 1; i <= 10; i++)
        for (int j = 1; j <= 10; j++)
        {
            blocks.push_back(sf::Sprite());
            blocks.back().setTexture(t1);
            blocks.back().setPosition(i * 43, j * 21 + 20);
        }

    for (int j = 1; j <= 10; j++)
    {
        blocks2.push_back(sf::Sprite());
        blocks2.back().setTexture(t9);
        blocks2.back().setPosition( j * 43, j * 21 + 20);
    }

    for (auto i = 1; i < 11; i++) 
    {
        blocks2.push_back(sf::Sprite());
        blocks2.back().setTexture(t9);
        blocks2.back().setPosition(43 * (11 - i), i * 21 + 20);
    }


    for (auto i = 0; i < 3; i++)
    {
        hearts.push_back(sf::Sprite());
        hearts.back().setTexture(t5);
        hearts.back().setPosition(50 * i, 10);
        hearts.back().setScale(0.1, 0.1);
    }

    bool bounce;
    bool waiting = true;
    int heart = 3;
    float dx = 0, dy = 0;
    float x = 260, y = 300;

    while (app.isOpen())
    {
        sf::Event e;
        while (app.pollEvent(e))
        {
            if (e.type == sf::Event::Closed)
            {
                app.close();
            }
        }
            
            bounce = true;
            x += dx;
            for (int i = 0; i < blocks.size(); i++)
                if (sf::FloatRect(x + 3, y + 3, 6, 6).intersects(blocks[i].getGlobalBounds()))
                {
                    blocks.erase(blocks.begin() + i);
                    dx = -dx;
                    bounce = false;
                }

            y += dy;
            for (int i = 0; i < blocks.size(); i++)
                if (sf::FloatRect(x + 3, y + 3, 6, 6).intersects(blocks[i].getGlobalBounds()))
                {
                    blocks.erase(blocks.begin() + i);
                    dy = -dy;
                    bounce = false;
                }

            for (int i = 0; i < blocks2.size(); i++)
                if (sf::FloatRect(x + 3, y + 3, 6, 6).intersects(blocks2[i].getGlobalBounds()) && bounce)
                {
                    dx = -dx + 1;      
                }

            for (int i = 0; i < blocks2.size(); i++)
                if (sf::FloatRect(x + 3, y + 3, 6, 6).intersects(blocks2[i].getGlobalBounds()) && bounce)
                {
                    dy = -dy + 1;
                }

            if (x < 0 || x > 520) 
            {
                dx = -dx;
            }

            if (y < 0) 
            {
                dy = -dy;
            }

            if (y > 450) 
            {
                dx = 0;
                dy = 0;
                x = 260;
                y = 300;
                heart--;
                waiting = true;

                hearts2.push_back(sf::Sprite());
                hearts2.back().setTexture(t6);
                hearts2.back().setPosition(50 * heart, 10);
                hearts2.back().setScale(0.10, 0.10);
            }

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)&& sPaddle.getPosition().x < 450) sPaddle.move(6, 0);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)&& sPaddle.getPosition().x > -10) sPaddle.move(-6, 0);
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space) && waiting) 
            {
                dx = 6;
                dy = 5;
                waiting = false;
            }
            
            if (sf::FloatRect(x, y, 12, 12).intersects(sPaddle.getGlobalBounds())) dy = -(rand() % 5 + 1);

            sBall.setPosition(x, y);     
            app.clear();
            app.draw(sBackground);
            app.draw(sBall);
            app.draw(sPaddle);
           
            
            if (heart == 0)
                {   
                Gameover.setScale(0.41, 0.65);
                Gameover.setPosition(0, -100);
                app.draw(Gameover);
                app.display();
                Sleep(3000);
                app.close();
                }

            if (blocks.empty()) 
            {   
                Win.setScale(0.915, 1.38);
                app.draw(Win);
                app.display();
                Sleep(3000);
                app.close();
            }
        
            for (auto item : hearts) 
            {
                app.draw(item);
            }

            for (auto item : hearts2) 
            {
                app.draw(item);
            }

            for (int i = 0; i < blocks.size(); i++) 
            {
                app.draw(blocks[i]);
            }

            for (int i = 0; i < blocks2.size(); i++) 
            {
                app.draw(blocks2[i]);
            }

            app.display();
            app.clear();
    }
    return 0;
}